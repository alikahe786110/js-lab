const booksContainer = document.querySelector("#books-container");
const booksList = document.querySelector("#books-list");
const selectedBooks = [];

books.forEach((book) => {
  const bookCard =
    `<div class="book-card book-${book.id}">` +
    `<img src="./Images/${book.id}.jpg" />` +
    `<h3>نام کتاب: ${book.title}</h3>` +
    `<h3>نام نویسنده: ${book.author}</h3>` +
    `<h3>تاریخ نشر: ${book.published_date}</h3>` +
    `<h3>زبان: ${book.language}</h3>` +
    `<h3>ژانر: ${book.genre}</h3>` +
    `<button>افزودن به کتابخانه من</button>` +
    `</div>`;
  booksContainer.innerHTML += bookCard;
});

for (const bookCard of booksContainer.children) {
  const addButton = bookCard.querySelector("button");

  addButton.addEventListener("click", (e) => {
    const clickedBookId = parseInt(
      e.target.parentNode.classList[1].split("-")[1]
    );

    if (!selectedBooks.includes(books[clickedBookId - 1])) {  
      selectedBooks.push(books[clickedBookId - 1]);
    }
    else {
      alert("کتاب تکراری")
    }
    booksList.innerHTML = "";
    // for (const selectedBook of selectedBooks) {
    //   booksList.innerHTML += selectedBook.title + "/ ";
    // }
    booksList.innerHTML += "کتابخانه من : " + selectedBooks.length;
  });
}
