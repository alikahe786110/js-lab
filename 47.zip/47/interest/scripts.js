

function calculateYears(principal, interest, tax, desired) {
     
    let y = 0; 
    let money = principal;
      while ( desired >  principal ) { 
        let sud =   principal * interest ; 
        principal = principal + sud - ( sud * tax) ; 
        y++ ;
         
      }
      console.log(y)
       return y;
      // your code
  }


    calculateYears(1000, 0.05, 0.18, 1100)
    calculateYears(1000,0.01625,0.18,1200)
    calculateYears(1000,0.05,0.18,1000)
