function shuffle(array) {
  let currentIndex = array.length,
    randomIndex;
  while (currentIndex != 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex],
      array[currentIndex],
    ];
  }

  return array;
}
let initboxes = [
  '<div class="show google-1"><i class="fab fa-google"></i></div>',
  '<div class="show google-2"><i class="fab fa-google"></i></div>',
  '<div class="show apple-1"><i class="fab fa-apple"></i></div>',
  '<div class="show apple-2"><i class="fab fa-apple"></i></div>',
  '<div class="show twitter-1"><i class="fab fa-twitter"></i></div>',
  '<div class="show twitter-2"><i class="fab fa-twitter"></i></div>',
  '<div class="show facebook-1"><i class="fab fa-facebook"></i></div>',
  '<div class="show facebook-2"><i class="fab fa-facebook"></i></div>',
  '<div class="show amazon-1"><i class="fab fa-amazon"></i></div>',
  '<div class="show amazon-2"><i class="fab fa-amazon"></i></div>',
  '<div class="show meta-1"><i class="fab fa-meta"></i></div>',
  '<div class="show meta-2"><i class="fab fa-meta"></i></div>',
  '<div class="show github-1"><i class="fab fa-github"></i></div>',
  '<div class="show github-2"><i class="fab fa-github"></i></div>',
  '<div class="show telegram-1"><i class="fab fa-telegram"></i></div>',
  '<div class="show telegram-2"><i class="fab fa-telegram"></i></div>',
];
const boxes = shuffle(initboxes);

/**************************************/

let section = document.querySelector("section");
section.innerHTML = "";
for (let i = 0; i < 16; i++) {
  section.innerHTML += boxes[i];
}

const myBoxes = section.querySelectorAll("div");
setTimeout(() => {
  for (const box of myBoxes) {
    box.classList.remove("show");
  }
}, 7000);

const message = document.querySelector("h1");
let time = 7;
setInterval(() => {
  message.innerHTML = `شروع بازی تا ${time - 2} ثانیه دیگر`;
  time--;
  if (time === 0) message.style.display = "none";
}, 1000);

/************************************ */

let firstDiv = "";
let secondDiv = "";
let guses = 0;
let correctGuses = 0;

function showCard() {
  guses++;
  if (!firstDiv) {
    firstDiv = this;
    firstDiv?.classList?.add("show");
  }
  if (this.className !== firstDiv.className && !secondDiv) {
    secondDiv = this;
    secondDiv?.classList?.add("show");
  }

  if (firstDiv?.innerHTML === secondDiv?.innerHTML) {
    firstDiv.classList.add("green");
    secondDiv.classList.add("green");
    correctGuses++;
    firstDiv = "";
    secondDiv = "";
  } else if (secondDiv) {
    firstDiv?.classList.toggle("show");
    secondDiv?.classList.toggle("show");
    firstDiv = "";
    secondDiv = "";
  }

  if (correctGuses === 8) {
    alert(`You Win :) ${guses / 2}`);
  }
}

for (const box of myBoxes) {
  box.onclick = showCard;
}
