const summary = { model: "", color: "", accessory: "" };

const stepBtns = document.querySelectorAll("button.step-btns");
const tikImgs = document.querySelectorAll("img.tik-img");
const modelsBoxes = document.querySelectorAll(".models");
const mainSection = document.querySelector("main");

const handleUpdateActiveStep = (stepBtn) => {
  for (const btn of stepBtns) {
    btn.classList.remove("active-step");
    btn.nextElementSibling?.classList.remove("active-step");
  }
  stepBtn.classList.add("active-step");
  stepBtn.nextElementSibling?.classList.add("active-step");
  mainSection.innerHTML = stepBtn.querySelector("div.content").innerHTML;
};

function handleSelectModel(element) {
  for (const modelsBox of modelsBoxes) {
    modelsBox.style = " border: gold 1px solid; box-shadow:none;";
  }

  for (const tikImg of tikImgs) {
    tikImg.style = "width: 70px; filter: grayscale(100%)";
  }

  element.querySelector("img.tik-img").style =
    "width: 70px; filter: grayscale(0%)";

  element.style =
    "box-shadow: 0px 0px 50px 0px #00B268; border: transparent 1px solid";
}

function handleSelectColor(element) {}

for (const stepBtn of stepBtns) {
  stepBtn.onclick = () => {
    handleUpdateActiveStep(stepBtn);
  };
}
