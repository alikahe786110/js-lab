

let input = document.querySelector("input");


function validatePhoneNumber(e) {
    let result = e.target.value.match(/^[0-9]{3}[0-9]{6}[0-9]$/);
    if (!result) {
        input.classList.add("error")
        input.classList.remove("valid")
    }
    else {
        input.classList.add("valid")
        input.classList.remove("error")
    }


}



input.addEventListener("keyup", validatePhoneNumber)