let persons = [
  {
    id: 0,
    name: "علی",
    Lname: "علوی",
    gender: "m",
    birthDay: "1375/09/06",
  },
  {
    id: 1,
    name: "عباس",
    Lname: "عباسی",
    gender: "w",
    birthDay: "1375/09/06",
  },
  {
    id: 2,
    name: "حسین",
    Lname: "حسینی",
    gender: "m",
    birthDay: "1375/09/06",
  },
  {
    id: 3,
    name: "علی",
    Lname: "کاهه",
    gender: "m",
    birthDay: "1375/09/06",
  },
  {
    id: 4,
    name: "سارا",
    Lname: "سارایی",
    gender: "w",
    birthDay: "1375/09/06",
  },
];

const addNewPersonBtn = document.querySelector("#add-new-person-btn");
const form = document.querySelector("form");
const formSubmitBtn = form.querySelector('input[type="submit"]');
const table = document.querySelector("table");
const formNameInput = document.querySelector("#form-name");
const formLnameInput = document.querySelector("#form-Lname");
const formGender = document.querySelector("#form-gender");
const formDay = document.querySelector("#form-day");
const formMonth = document.querySelector("#form-month");
const formYear = document.querySelector("#form-year");
const closeFormBtn = form.querySelector("#close-form-btn");
const filterValue = document.querySelector("#filter-value");
const filterBtn = document.querySelector("#filter-btn");
const clearFiltersBtn = document.querySelector("#clear-filters-btn");

let flagEdit = false;
let editThisPerson = null;

function renderItemsToTable(data) {
  table.innerHTML = "";
  table.innerHTML = `
    <tr>
      <th>نام</th>
      <th>نام خانوادگی</th>
      <th>جنسیت</th>
      <th>تاریخ تولد</th>
      <th>ویرایش</th>
      <th>حذف</th>
    </tr>`;
  data.forEach((person) => {
    const newTr = `
            <tr>
                <td>${person.name}</td>
                <td>${person.Lname}</td>
                <td>${person.gender === "m" ? "مرد" : "زن"}</td>
                <td>${person.birthDay}</td>
                <td><button class='editBtn-${person.id}'>ویرایش</button></td>
                <td><button class='deleteBtn-${person.id}'>حذف</button></td>
            </tr>
        `;
    table.innerHTML += newTr;
  });
  data.forEach((person) => {
    document
      .querySelector(`.editBtn-${person.id}`)
      .addEventListener("click", () => {
        editPerson(person);
      });
    document
      .querySelector(`.deleteBtn-${person.id}`)
      .addEventListener("click", () => {
        deletePerson(person);
      });
  });
}
renderItemsToTable(persons);

function openForm() {
  form.style.top = "0px";
}

function closeForm() {
  form.style.top = "-100vh";
}

function editPerson(person) {
  formNameInput.value = person.name;
  formLnameInput.value = person.Lname;
  flagEdit = true;
  editThisPerson = person;
  openForm();
}

function deletePerson(person) {
  persons = persons.filter((item) => {
    return item.id !== person.id;
  });
  renderItemsToTable(persons);
}

function addNewPerson() {
  if (flagEdit) {
    persons = persons.map((item) => {
      if (item.id === editThisPerson.id)
        return {
          ...item,
          name: formNameInput.value,
          Lname: formLnameInput.value,
          gender: formGender.value,
          birthDay: `${formYear.value}/${formMonth.value}/${formDay.value}`,
        };
      return { ...item };
    });
    renderItemsToTable(persons);
  } else {
    if (formNameInput.value && formLnameInput.value && formGender.value) {
      persons.push({
        id: new Date().getTime(),
        name: formNameInput.value,
        Lname: formLnameInput.value,
        gender: formGender.value,
        birthDay: `${formYear.value}/${formMonth.value}/${formDay.value}`,
      });
      renderItemsToTable(persons);
    }
  }

  formNameInput.value = "";
  formLnameInput.value = "";
  flagEdit = false;
  editThisPerson = null;
}

function filterPersons() {
  if (filterValue.value) {
    const filteredPersonsArr = persons.filter((person) => {
      return (
        person.name.includes(filterValue.value) ||
        person.Lname.includes(filterValue.value)
      );
    });
    renderItemsToTable(filteredPersonsArr);
  }
}

function clearFilters() {
  filterValue.value = "";
  renderItemsToTable(persons);
}

addNewPersonBtn.addEventListener("click", openForm);
formSubmitBtn.addEventListener("click", () => {
  formNameInput.value && formLnameInput.value && closeForm();
});
form.addEventListener("submit", function (e) {
  e.preventDefault();
});
formSubmitBtn.addEventListener("click", addNewPerson);
closeFormBtn.addEventListener("click", closeForm);
filterBtn.addEventListener("click", filterPersons);
clearFiltersBtn.addEventListener("click", clearFilters);
