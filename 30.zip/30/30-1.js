// let img = Math.floor(Math.random() * 10);
// debugger;
// document.body.style.backgroundImage = `url('https://my.bmi.ir/portalserver/static/ibank/widgets/bmi-change-background-random/data/images/${img}.jpg') `;

const images = [
  { src: 1, text: "عکس شماره ۱" },
  { src: 2, text: "عکس شماره 2" },
  { src: 3, text: "عکس شماره 3" },
];

const index = Math.floor(Math.random() * 3);

document.body.style.backgroundImage = `url('./img/${images[index].src}.jpg')`;
document.body.style.backgroundSize = "cover";

document.querySelector("h1").innerHTML = images[index].text;
