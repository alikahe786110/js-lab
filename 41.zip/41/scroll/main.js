let header = document.querySelector("header");

window.addEventListener("scroll", function () {
  if (window.scrollY < 400) {
    header.classList.add("change");
  } else {
    header.classList.remove("change");
  }
});
