const circle1 = document.getElementById("circle1");
const circle2 = document.getElementById("circle2");
const Square1 = document.getElementById("Square1");
const Square2 = document.getElementById("Square2");

const moveVar = (X, Y, width, height) => {
  return `translate(${-(width - X) / 12}px,${(height - Y) / 12}px)`;
};

// event object
function mouseTracking(e) {
  let Y = e.clientY;
  let X = e.clientX;
  let width = window.innerWidth;
  let height = window.innerHeight;
  circle1.style.transform = moveVar(X, Y, width, height);
  circle2.style.transform = moveVar(X, Y, width, height);
  Square1.style.transform = moveVar(X, Y, width, height);
  Square2.style.transform = moveVar(X, Y, width, height);
}

// event
window.addEventListener("mousemove", mouseTracking);
