// dom nodes
// let root = document.getElementById("root");
// let count = document.getElementById("store-count");
// let homecount = document.getElementById("home-count");
// let storBtn = document.getElementById("store");
// let homeBtn = document.getElementById("home");

let root = $("#root");
let count = $("#store-count");
let homecount = $("#home-count");
let storBtn = $("#store");
let homeBtn = $("#home");

const MY_FILM_STORE = [
  {
    title: "title01",
    episode_id: 01,
    opening_crawl: "opening_crawl01",
    director: "director01",
    producer: "producer01",
    release_date: "release_date01",
  },
];

// functions

function render(list) {
  let template = list
    .map(function (film) {
      const {
        episode_id,
        title,
        opening_crawl,
        director,
        producer,
        release_date,
      } = film;

      return `
            <div class="col-3 p-2">
            <div class="card ">
                <img src="./filmImages/${episode_id}.jfif" alt="film1" height="388">
                <div class="card-body">
                    <h2>${title}</h2>
                    <div class="episode_id">episode_id: <span class="value">${episode_id}</span></div>
                    <div class="opening_crawl">opening_crawl: <span class="value">${opening_crawl}</span></div>
                    <div class="director">director: <span class="value">${director}</span></div>
                    <div class="producer">producer: <span class="value">${producer}</span></div>
                    <div class="release_date">release_date: <span class="value">${release_date}</span></div>
                    <div class="cta my-3">
                    ${
                      MY_FILM_STORE.find(function (b) {
                        return b.episode_id === film.episode_id;
                      })
                        ? `<button class="btn btn-success">Availableto films</button>`
                        : `<button class="btn btn-primary" onclick="addToStore(${film.episode_id})">add to my films</button>`
                    }
                    </div>
                </div>
            </div>
        </div>
        `;
    })
    .join("");
  root.html(template);
  // root.innerHTML = template;
  showMyStoreLength();
}

function addToStore(episode_id) {
  let findfilm = FILMS.find(function (film) {
    return film.episode_id === episode_id;
  });
  MY_FILM_STORE.push(findfilm);
  render(FILMS);
}

function removeFromStore(episode_id) {
  let index = MY_FILM_STORE.findIndex(function (film) {
    return film.episode_id === episode_id;
  });
  MY_FILM_STORE.splice(index, 1);
  myStoreRender(MY_FILM_STORE);
  Toastify({
    text: "Success ",
    duration: 3000,
    newWindow: true,
    close: true,
    gravity: "top", // `top` or `bottom`
    position: "center", // `left`, `center` or `right`
    stopOnFocus: true, // Prevents dismissing of toast on hover
    style: {
      background: "linear-gradient(to right, red, darkred)",
    },
  }).showToast();
  showMyStoreLength();
}

function showMyStoreLength() {
  // count.textContent = MY_FILM_STORE.length;
  count.html(MY_FILM_STORE.length);
}

function showStorefilms() {
  myStoreRender(MY_FILM_STORE);
}

function showAllfilms() {
  render(FILMS);
}

function myStoreRender(MY_FILMS) {
  let template = `
    <div id="my-store">
    <table class="table text-white">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">image film</th>
            <th scope="col">title</th>
            <th scope="col">opening_crawl</th>
            <th scope="col">action</th>

        </tr>
    </thead>
    <tbody>`;
  template += MY_FILMS.map(function (film, index) {
    const {
      episode_id,
      title,
      opening_crawl,
      director,
      producer,
      release_date,
    } = film;
    return `
        <tr>
                    <th scope="row">${index + 1}</th>
                    <td>
                        <img src="./filmImages/${episode_id}.jpg" height="100">
                    </td>
                    <td>${title}</td>
                    <td>${opening_crawl}</td>
                    <td><button class="btn btn-danger" onclick="removeFromStore(${episode_id})">delete for my films</button></td>
        </tr>
        `;
  }).join("");

  template += `</tbody></table></div>`;
  root.html(template);
  // root.innerHTML = template;
}

function getData() {
  console.log(req);
  if (req.readyState === 4 && req.status === 200) {
    let data = jQuery.parseJSON(req.response);
    // let mybooksFromLocal = jQuery.parseJSON(localStorage.getItem("mybooks")) || [];
    // let mybooksFromLocal =$get(localStorage.getItem("mybooks")) || []

    data.results.map((film) => {
      FILMS.push(film);
    });
    homecount.textContent = data.count;
    render(FILMS);
  }

  if (req.status !== 200) {
    alert("Error!!!");
  }
}

// let req = new XMLHttpRequest();
// req.open("GET", "https://swapi.dev/api/films");
// req.addEventListener("readystatechange", getData);
// req.send();

$.ajax({
  url: "https://swapi.dev/api/films",
  method: "get",
  success: function (res) {
    // $res.results.click("readystatechange", getData);
    console.log(res.results);
    render(res.results);
  },
});

// render(FILMS);
// storBtn.addEventListener("click", showStorefilms);
// homeBtn.addEventListener("click", showAllfilms);

storBtn.on("click", (e) => {
  console.log(e.target);
  showStorefilms();
});
homeBtn.on("click", (e) => {
  showAllBooks();
});
