// dom nodes
// let root = document.getElementById("root");
// let count = document.getElementById("store-count");
// let storBtn = document.getElementById("store")
// let homeBtn = document.getElementById("home");

let root = $("#root");
let count = $("#store-count");
let storBtn = $("#store");
let homeBtn = $("#home");

let mybooksFromLocal = jQuery.parseJSON(localStorage.getItem("mybooks")) || [];
// let mybooksFromLocal =$get(localStorage.getItem("mybooks")) || []
const MY_BOOK_STORE = mybooksFromLocal;

// functions
function render(list) {
  let template = list
    .map(function (book) {
      return `
            <div class="col-3 p-2">
            <div class="card ">
                <img src="./bookImages/${book.id}.jpg" alt="book1" height="388">
                <div class="card-body">
                    <h2>${book.title}</h2>
                    <div class="author">نویسنده: <span class="value">${
                      book.author
                    }</span></div>
                    <div class="release">تاریخ انتشار: <span class="value">${
                      book.published_date
                    }</span></div>
                    <div class="language">زبان: <span class="value">${
                      book.language
                    }</span></div>
                    <div class="genre">ژانر: <span class="value">${
                      book.genre
                    }</span></div>
                    <div class="cta my-3">
                    ${
                      MY_BOOK_STORE.find(function (b) {
                        return b.id === book.id;
                      })
                        ? `<button class="btn btn-success">موجود در کتابخانه</button>`
                        : `<button class="btn btn-primary" onclick="addToStore(${book.id})">اضافه به کتابخانه من</button>`
                    }
                    </div>
                </div>
            </div>
        </div>
        `;
    })
    .join("");
  root.html(template);
  // root.innerHTML = template;
  showMyStoreLength();
}

function addToStore(id) {
  let findBook = BOOKS.find(function (book) {
    return book.id === id;
  });
  MY_BOOK_STORE.push(findBook);
  render(BOOKS);

  console.log(MY_BOOK_STORE);

  // add to localstorage
  localStorage.setItem("mybooks", JSON.stringify(MY_BOOK_STORE));
}

function removeFromStore(id) {
  let index = MY_BOOK_STORE.findIndex(function (book) {
    return book.id === id;
  });
  MY_BOOK_STORE.splice(index, 1);
  myStoreRender(MY_BOOK_STORE);
  localStorage.setItem("mybooks", JSON.stringify(MY_BOOK_STORE));
  Toastify({
    text: "با موفقیت حذف شد",
    duration: 3000,
    newWindow: true,
    close: true,
    gravity: "top", // `top` or `bottom`
    position: "center", // `left`, `center` or `right`
    stopOnFocus: true, // Prevents dismissing of toast on hover
    style: {
      background: "linear-gradient(to right, red, darkred)",
    },
  }).showToast();
  showMyStoreLength();
}

function showMyStoreLength() {
  count.html(MY_BOOK_STORE.length);
}

function showStoreBooks() {
  myStoreRender(MY_BOOK_STORE);
}

function showAllBooks() {
  render(BOOKS);
}

function myStoreRender(MY_BOOKS) {
  let template = `
    <div id="my-store">
    <table class="table text-white">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">تصویر کتاب</th>
            <th scope="col">نام کتاب</th>
            <th scope="col">نویسنده</th>
            <th scope="col">عملیات</th>

        </tr>
    </thead>
    <tbody>`;
  template += MY_BOOKS.map(function (book, index) {
    return `
        <tr>
                    <th scope="row">${index + 1}</th>
                    <td>
                        <img src="./bookImages/${book.id}.jpg" height="100">
                    </td>
                    <td>${book.title}</td>
                    <td>${book.author}</td>
                    <td><button class="btn btn-danger" onclick="removeFromStore(${
                      book.id
                    })">حذف از کتابخانه من</button></td>
        </tr>
        `;
  }).join("");

  template += `</tbody></table></div>`;
  root.html(template);
  // root.innerHTML = template
}

render(BOOKS);
// storBtn.addEventListener("click", showStoreBooks)
// homeBtn.addEventListener("click", showAllBooks)

storBtn.on("click", (e) => {
  console.log(e.target);
  showStoreBooks();
});
homeBtn.on("click", (e) => {
  showAllBooks();
});
