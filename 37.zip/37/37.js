
function timeCoffeeMaker(times) {

    debugger;

    let sumTime = 0;
    times.sort();
    let timeOut = []
    let conter = 0;
    for (const time of times) {             
        if (conter == 0 ) {
            sumTime+=time;
        }
        else {
            sumTime+=time+2 ;
        }
        conter+=
        timeOut.push(sumTime)
        
    }
    sumTime=0
    for (const time of timeOut) {             

        sumTime=sumTime+time;
        
    }

    return sumTime
}

let timesIn = [4,2,6];

alert(timeCoffeeMaker(timesIn))