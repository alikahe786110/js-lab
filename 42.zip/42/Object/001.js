// data types
// Object, OOP
// literaly

// let student = {
//   name: "Sana",
//   family: "Samin",
//   score: 100,
//   age: 30,
//   course: ["NodeJs", "php"],
//   phoneNumber: "09121001010",
//   studentNumber: "MFT123456S",
//   isCertfifcate: true,
//   address: {
//     city: "Shiraz",
//     Province: "Fars",
//     PostaCode: 148898763,
//   },
//   calculateStudentRank: function () {
//     return "A";
//   },
//   getFullName: function () {
//     return this.name + " " + this.family;
//   },
// };

// console.log(student.calculateStudentRank());
// console.log(student.getFullName());
// console.log(student["name"]);

const students = [
  {
    name: "name01",
    lName: "lNmae01",
    age: "age01",
    pNo: "pNo01",
    courses: ["lesson0101", "lesson0102"],
  },
  {
    name: "name02",
    lName: "lNmae02",
    age: "age02",
    pNo: "pNo02",
    courses: ["lesson0201", "lesson0202"],
  },
  {
    name: "name03",
    lName: "lNmae03",
    age: "age03",
    pNo: "pNo03",
    courses: ["lesson0301", "lesson0302"],
  },
];

const table = document.querySelector("#my-table");
const tbody = table.querySelector("#t-body");

students.forEach((student) => {
  const tr = document.createElement("tr");
  for (const key in student) {
    const td = document.createElement("td");
    td.textContent = student[key];
    tr.appendChild(td);
  }
  table.appendChild(tr);
});
