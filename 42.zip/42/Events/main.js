let events = document.querySelectorAll("div");
let h2 = document.querySelector("h2");

let x = 0;

function handleEvent() {
  x = x + 1;
  if (x % 2 === 0) h2.textContent = x;
}

for (const div of events) {
  div.addEventListener(div.textContent, handleEvent);
}
