

// source of truth
const STUDENTS = [
    "sana samin", 
    "arman pasyandeh", 
    "reza rahsepar", 
    "hoda rahmati", 
    "sanaz khodabande",
    "hadi haghnezhad"
]