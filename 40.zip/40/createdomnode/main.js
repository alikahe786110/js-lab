

let ul = document.getElementById("root")

for (const student of STUDENTS) {
    let li = document.createElement("li");
    let namefamily = student.split(" ")
    let name=namefamily[0].substr(0,1).toUpperCase()+namefamily[0].substr(1)
    let family=namefamily[1].substr(0,1).toUpperCase()+namefamily[1].substr(1)
    let nameAndFamily=name+" "+family
    li.textContent = nameAndFamily;
    ul.appendChild(li)

}