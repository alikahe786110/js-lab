// dom nodes
let btnAdd = document.querySelector(".btnAdd");
let btnDelete = document.querySelector(".btnDelete");
let btnUpdate = document.querySelector(".btnUpdate");
let btnSelectAll = document.querySelector(".btnSelectAll");
let btnUnSelectAll = document.querySelector(".btnUnSelectAll");

let input = document.querySelector("input");
let root = document.getElementById("root");




// functions

function SelectToDo() {
  let li = document.createElement("li");
  li.addEventListener("click", (clickedLi) => {
    if (clickedLi?.target?.style.textDecoration === "line-through" ) {
      clickedLi.target.style = "";
    }else {
      clickedLi.target.style = "text-decoration: line-through;";
    }
  });
  }

function SelectAllToDo() {
  const lis = document.querySelectorAll("li");
  for (const li of lis) {
    li.style =  "text-decoration: line-through;";
  }
}

function UnSelectAllToDo() {
  const lis = document.querySelectorAll("li");
  for (const li of lis) {
    li.style = "";
  }
}
let last_id = "";
function AddToDo() {
  if (input.value !== "") {
    let li = document.createElement("li");
    li.setAttribute("id", Math.random().toString(16).slice(2));
    li.addEventListener("click", (clickedLi) => {
      if (clickedLi?.target?.style.textDecoration === "line-through" ) {
        clickedLi.target.style = "";
      }else {
        clickedLi.target.style = "text-decoration: line-through;";
        input.value = clickedLi.target.textContent;
        last_id = li.getAttribute("id");
        console.log(last_id)
      }
    });
    li.textContent = input.value;
    root.appendChild(li);
    input.value = "";
  } else {
    alert("خالی وارد نکن");
  }
  input.focus();
}

function  DeleteToDo() {
  const lis = document.querySelectorAll("li");
  for (const li of lis) {
    if (li.style.textDecoration === "line-through" ) {
      li.textContent = "";
      root.removeChild(li);
    }
  }
}

function  UpdateToDo() {
  debugger;
  console.log(document.getElementById(last_id));
  document.getElementById(last_id).textContent  = input.value;
}





// events

btnAdd.onclick = AddToDo;
btnDelete.onclick = DeleteToDo;
btnUpdate.onclick = UpdateToDo;
btnSelectAll.onclick = SelectAllToDo;
btnUnSelectAll.onclick = UnSelectAllToDo;


