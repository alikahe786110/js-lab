const result = countries.reduce(function (r, a) {
  r[a[0]] = r[a[0]] || [];
  r[a[0]].push(a);

  return r;
}, Object.create(null));

for (const item in result) {
  console.log(`${item.toUpperCase()}(${result[item].length})`);
  for (const country of result[item]) {
    console.log(country.toLowerCase());
  }
}
