
let body = document.querySelector("body");

function arraySort() { 
    countries.sort();
    const result = countries.reduce(function (r, a) {
      r[a[0]] = r[a[0]] || [];
      r[a[0]].push(a);

      return r;
    }, Object.create(null));

    for (const item in result) {
      let uperAndCount=`${item.toUpperCase()}(${result[item].length})`;
      // console.log(uperAndCount);
      body.innerHTML += `
          <div >
              <h2>${uperAndCount}</h2>
          </div>
  `;

      for (const country of result[item]) {
        let lower = country.toLowerCase();
        body.innerHTML += `
        <div >
            <h3>${lower}</h3>
        </div>
`;
        // console.log(lower);
      }
    }
}

arraySort()
