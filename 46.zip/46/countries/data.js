const countries = [
  "iran",
  "australia",
  "brezil",
  "usa",
  "germany",
  "finland",
  "china",
  "norway"
];
