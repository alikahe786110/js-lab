const countries = [
  "iran",
  "iraq",
  "australia",
  "brezil",
  "usa",
  "germany",
  "finland",
  "china",
  "norway"
];
