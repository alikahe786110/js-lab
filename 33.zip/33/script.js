const imagePerviewContainer = document.querySelector(
  "div.image-perview-container"
);

let selectedImage;

function showThisImage(element) {
  if (selectedImage) {
    selectedImage.style.border = "none";
  }

  imagePerviewContainer.innerHTML = `<img src="${element.src}"/>`;
  element.style.border = "solid red 3px";
  selectedImage = element;
}
