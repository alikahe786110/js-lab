// dom nodes
let root = document.getElementById("root");
let count = document.getElementById("store-count");
let storBtn = document.getElementById("store");
let homeBtn = document.getElementById("home");
const filtersContainer = document.querySelector("#filters-container");

const MY_BOOK_STORE = [];

// functions
function render(list) {
  let template = list
    .map(function (book) {
      return `
        <div class="col-3 p-2">
            <div class="card ">
                <img src="./bookImages/${book.id}.jpg" alt="book1" height="388">
                <div class="card-body">
                    <h2>${book.title}</h2>
                    <div class="author">نویسنده: <span class="value">${
                      book.author
                    }</span></div>
                    <div class="release">تاریخ انتشار: <span class="value">${
                      book.published_date
                    }</span></div>
                    <div class="language">زبان: <span class="value">${
                      book.language
                    }</span></div>
                    <div class="genre">ژانر: <span class="value">${
                      book.genre
                    }</span></div>
                    <div class="cta my-3">
                        ${
                          MY_BOOK_STORE.find(function (b) {
                            return b.id === book.id;
                          })
                            ? `<button class="btn btn-success">موجود در کتابخانه</button>`
                            : `<button class="btn btn-primary" onclick="addToStore(${book.id})">اضافه به کتابخانه من</button>`
                        }
                    </div>
                </div>
            </div>
        </div>
        `;
    })
    .join("");
  root.innerHTML = template;
  showMyStoreLength();
}

function addToStore(id) {
  let findBook = BOOKS.find(function (book) {
    return book.id === id;
  });
  MY_BOOK_STORE.push(findBook);
  render(BOOKS);
}

function showMyStoreLength() {
  count.textContent = MY_BOOK_STORE.length;
}

function showStoreBooks() {
  render(MY_BOOK_STORE);
}

function showAllBooks() {
  render(BOOKS);
}

function showFilteredBooks(filterBy, filterItem) {
  const filteredBooks = BOOKS.filter((book) => {
    return book[filterBy] === filterItem;
  });
  render(filteredBooks);
}
// function showFilteredBooks(key) {
//   console.log("key: ", key);
//   const filteredBooks = BOOKS.filter((book) => {
//     return book.genre === key;
//   });
//   render(filteredBooks);
// }

function filters(books) {
  for (const item of BOOKSMeaning) {
    const result = books.reduce(function (r, a) {
      r[a[item.key]] = r[a[item.key]] || [];
      r[a[item.key]].push(a);
      return r;
    }, Object.create(null));

    filtersContainer.innerHTML += `<hr><h2 class = "text-white">${item.value}</h2>`;

    for (const key in result) {
      // const myForm = document.createElement("form");
      const myDiv = document.createElement("div");
      myDiv.classList.add("d-flex");
      myDiv.classList.add("gap-2");
      myDiv.classList.add("m-2");
      myDiv.classList.add("text-white");
      myDiv.setAttribute("id", key);

      myDiv.innerHTML = `
      <input
        type="checkbox"
        id="${item.key}-${key}"
        class="checks"
      />
      <label for="${item.key}-${key}" id="${item.key}-${key}" >${key} (${result[key].length})</label>
    `;

      filtersContainer.appendChild(myDiv);
    }
  }
}

filtersContainer.addEventListener("click", (e) => {
  console.log(e.target);

  let flag = false;

  const idItems = e.target.id.split("-");
  const filterBy = idItems[0];
  const filterItem = idItems[1];

  for (const item of BOOKSMeaning) {
    if (filterBy === item.key) {
      flag = true;
      break;
    }
  }

  flag && showFilteredBooks(filterBy, filterItem);
});

filters(BOOKS);

render(BOOKS);
storBtn.addEventListener("click", showStoreBooks);
homeBtn.addEventListener("click", showAllBooks);
