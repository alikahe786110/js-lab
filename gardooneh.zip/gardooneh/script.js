const gardoonehCircle = document.querySelector(".gardooneh-circle");
const vector = gardoonehCircle.querySelector(".vector");

const degrees = [0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330];

gardoonehCircle.addEventListener("click", () => {
  const rotateDegree =
    degrees[Math.floor(Math.random() * (11 - 0 + 1) + 0)] + 360;

  vector.style = `animation-name: rotate`;
  setTimeout(() => {
    vector.style = `animation-name: none`;
    vector.style = `transform: rotate(${1800 - rotateDegree}deg);`;
  }, 5000);
});
