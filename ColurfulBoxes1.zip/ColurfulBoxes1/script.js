let boxes = document.querySelectorAll("section > div");

let firstDiv = "";
let secondDiv = "";
let correctGuses = 0;
// debugger;
function showCard() {
  if (!firstDiv) {
    firstDiv = this;
    firstDiv?.classList?.add("show");
    console.log(firstDiv)

  }
  if (this.className !== firstDiv.className && !secondDiv) {
    secondDiv = this;
    secondDiv?.classList?.add("show");
  }

  if (firstDiv?.innerHTML === secondDiv?.innerHTML) {
    firstDiv.classList.add("green");
    secondDiv.classList.add("green");
    correctGuses++;
    firstDiv = "";
    secondDiv = "";
  } else if (secondDiv) {
    firstDiv?.classList.toggle("show");
    secondDiv?.classList.toggle("show");
    firstDiv = "";
    secondDiv = "";
  }

  if (correctGuses === 8) {
    alert("You Win :)");
  }
  console.log("firstDiv", firstDiv);
  console.log("secondDiv", secondDiv);
}

for (const box of boxes) {
  box.onclick = showCard;
}
