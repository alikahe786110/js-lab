

// dom nodes
let boxes = document.querySelectorAll("section > div")
let counter = 0

// functions
function changeBackgroundColor() {
    console.log(counter)
    if (!this.style.backgroundColor) {
        let red = Math.floor(Math.random() * 256);
        let green = Math.floor(Math.random() * 256);
        let blue = Math.floor(Math.random() * 256);
        this.style.backgroundColor = `rgb(${red},${green},${blue})`;
        counter++;
    }

    if(counter === 16)
        alert("FINISHED!!!")
}



// events
for (const box of boxes) {
    box.onclick = changeBackgroundColor;
}