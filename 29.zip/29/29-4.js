
function f_random () {
    debugger;
    let v_random = 0;
    v_random = Math.random();
    v_random = Math.round(v_random * 10);
    alert ( "عدد : " + v_random);
    // return v_random;
}

// let v_random = f_random();
// alert ( "عدد : " , v_random);


