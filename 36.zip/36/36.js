function sumNumbers ( arrys) { 
    let sum = 0;
    for (const arry of arrys) {
        if(typeof(arry)==="number") sum+=arry
    }
    return sum
}

alert("sum: "+sumNumbers(['a',2,false,4]));