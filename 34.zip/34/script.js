const colorsCharacters = "0123456789abcdef";
let counter = 0;

function changeBackColor(e) {
  const R = colorsCharacters[Math.floor(Math.random() * (15 - 0 + 1) + 0)];
  const G = colorsCharacters[Math.floor(Math.random() * (15 - 0 + 1) + 0)];
  const B = colorsCharacters[Math.floor(Math.random() * (15 - 0 + 1) + 0)];

  if (e.style.backgroundColor === "rgb(136, 136, 136)") {
    e.style.backgroundColor = `#${R}${G}${B}`;
    counter++;
    if (counter === 16) alert("The End!");
  }
}
