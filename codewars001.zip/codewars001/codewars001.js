function greet(name){
    //your code here
    alert(`Hello, ${name} how are you doing today?`);
  }
debugger;
  greet("ali");