

let fahrenheit = prompt("عدد فارنهایت را وارد کنید");
celsius = (fahrenheit - 32) * 5.9
prompt("سلسیوس عبارتست از : " ,celsius );
console.log(celsius);