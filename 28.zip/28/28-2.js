let number = prompt("عدد وارد کنید");
if (number % 2 == 0 ) {
    alert("عدد زوج" );
}
else  {
    alert("عدد فرد" );
}

