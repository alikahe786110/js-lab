
// کد اسکی : 
// اعداد : 
// فارسی 0 تا 9 : 48 تا 57 
// لاتین : 0 تا 9 : 48 تا 57
// حروف : 
// فارسی ا تا ی : 
// لاتین کوچک a  تا z  : 97 تا 122
// لاتین بزرگ  A تا Z : 65 تا 90




let password = "";

let sHarfLatin = 0;
let bHarfLatin = 0;
let adad = 0;
let selectedValue ;


for ( let i =0 ; i<8 ; i++) {
    sHarfLatin = 97+Math.floor(Math.random()*26);
    bHarfLatin = 65+Math.floor(Math.random()*26);
    adad = 48+Math.floor(Math.random()*10);
    const randomNumber = Math.floor(Math.random()*3);
    if ( randomNumber === 0 ) {
        selectedValue = sHarfLatin 
    }
    if ( randomNumber === 1 ) {
        selectedValue = bHarfLatin 
    }
    if ( randomNumber === 2 ) {
        selectedValue = adad 
    }

    password = password + String.fromCharCode(selectedValue);
}
console.log(password);

