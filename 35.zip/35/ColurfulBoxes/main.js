// dom nodes
let boxes = document.querySelectorAll("section > div");
let counter = 0;
let openCards = [];

// functions
function showCard() {
  counter++;
  this.classList.add("show");
  openCards.push(this);

  if (counter == 2) {
    if (openCards[0].innerHTML === openCards[1].innerHTML) {
      openCards[0].classList.add("green");
      openCards[1].classList.add("green");
    }
    openCards = [];
    counter = 0;
  }
}

// events
for (const box of boxes) {
  box.onclick = showCard;
}
